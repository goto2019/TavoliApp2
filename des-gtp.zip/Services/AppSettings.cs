namespace TavoliApp.Services
{
    public static class AppSettings
    {
        public static string ServerIp { get; set; } = string.Empty;
    }
}