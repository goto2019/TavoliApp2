using Microsoft.Maui.Controls;
using TavoliApp.ViewModels;
using System;

namespace TavoliApp.AppViews
{
    public partial class LoginPage : ContentPage
    {
        private readonly IServiceProvider _serviceProvider;

        public LoginPage(IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _serviceProvider = serviceProvider;
            BindingContext = new LoginViewModel(_serviceProvider);
        }
    

        private void OnLoginClicked(object sender, EventArgs e)
        {
            if (BindingContext is LoginViewModel vm && vm.LoginCommand.CanExecute(null))
                vm.LoginCommand.Execute(null);
        }
    }
}
